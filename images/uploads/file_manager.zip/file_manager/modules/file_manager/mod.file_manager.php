<?php

/*
=====================================================
 ExpressionEngine - by pMachine
-----------------------------------------------------
 http://www.pmachine.com/
=====================================================
 This module was created by Lodewijk Schutte
 - lodewijk@gmail.com
 - http://loweblog.com/
 This work is licensed under a
 Creative Commons Attribution-ShareAlike 2.5 License.
 - http://creativecommons.org/licenses/by-sa/2.5/
=====================================================
 File: mod.file_manager.php
-----------------------------------------------------
 Purpose: Dummy File Manager class
=====================================================
*/


if ( ! defined('EXT'))
{
    exit('Invalid file request');
}


class File_manager {

    var $return_data	= ''; 

    // -------------------------------------
    //  Constructor
    // -------------------------------------

    function File_manager()
    {
      // ...
    }

}


?>