*** File Manager module for ExpressionEngine ***

Date modified    : 2008.10.30
Current version  : 1.2.5


INSTALLATION:
- Unzip file_manager.zip
- Upload the folder /file_manager and its contents to your system/modules folder
- Upload the file lang.file_manager.php to your system/language/english folder
- In your Control Panel under Modules, install the File Manager module

UPGRADE:
- Unzip file_manager.zip
- Upload and replace the folder /file_manager and its contents
- Upload and replace the file lang.file_manager.php
- In your Control Panel under Modules, visit File Manager module and click the upgrade link


For more details, please visit
http://loweblog.com/freelance/article/ee-file-manager-module/

